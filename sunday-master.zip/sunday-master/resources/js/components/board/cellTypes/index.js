import InputDate from "./Date";
import InputLabel from "./Label";
import InputPerson from "./Person";
import InputTime from "./Time";

export default {
    InputDate,
    InputLabel,
    InputPerson,
    InputTime
}

